Thank you for using my Sprite pack!
Credit goes out to the creators of DDLC and MAS team! (since I have edited their textures)

------------------------------------------------------------

To install simply;

1. cut the "game" folder and paste it into the folder with your ddlc files! (Most times this folder is named DDLC)

2. Make sure you don't paste the folder INTO the already existing "game" one, paste it beside it

3. If your computer asks to overwrite files allow it

4. You are all set! Restart or open your MAS 

------------------------------------------------------------

If any issues and/or requests arise message me on discord @terrorgunz
I will try to update this when I get new ideas 


SoftFaceMonika by Terrorgunz

<3